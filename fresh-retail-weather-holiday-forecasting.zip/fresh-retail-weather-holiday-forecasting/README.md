# Does weather and holiday data improve sales forecasts for fresh retail?

Capstone project: do weather and holiday information make **day-ahead sales forecasts** for fresh products more accurate than a strong forecast built only on past sales, calendar and price?

**Short answer (90 days of data, one retailer):** holidays help a little, mainly on public-holiday days and for unpredictable products. Weather did **not** help item-level forecasts and made them slightly worse.

📄 **Full write-up:** [`report/Executive_Report.pdf`](report/Executive_Report.pdf)

## Key results

Forecast error (RMSE, lower is better) on 21 unseen days (5–25 June 2024), non-stockout days. Models trained on 41 days for a random sample of 8,000 of the 50,000 store-product series.

| Inputs | Random Forest | XGBoost |
|---|---|---|
| Baseline (sales lags 1/7/14/28 days, rolling 7-day mean, day of week, trend, discount, promo flag) | 0.549 | 0.609 |
| + holidays | **0.540** | **0.606** |
| + weather | 0.569 | 0.647 |
| + weather + holidays | 0.558 | 0.637 |
| Naive (same weekday last week) | 0.752 | 0.752 |

- Holidays: Random Forest RMSE −1.7% overall (95% bootstrap interval excludes zero) and −7.6% on weekday public-holiday days; largest gain for the 66 "unpredictable" products (8–12%).
- Weather: +3.5% (Random Forest) to +6.3% (XGBoost) *worse*.
- Stockouts: 17.5% of store-product days had at least 8 of 16 selling hours out of stock. Those days are excluded from training and testing, because sales are not demand.

## Data

| Source | Description | Size |
|---|---|---|
| [FreshRetailNet-50K](https://huggingface.co/datasets/Dingdong-Inc/FreshRetailNet-50K) | Real fresh-retail sales, stock status, discounts, holidays and weather, 28 Mar – 25 Jun 2024, 898 stores, 865 products, 18 cities | 4.5M rows |
| [Open-Meteo](https://open-meteo.com/en/docs) | Daily weather for 18 Chinese cities (temperature, rainfall, sunshine, wind) | 2,196 rows × 8 columns |

See [`data/README.md`](data/README.md) for how to download them (raw files are not committed).

## Methods

1. **Cleaning:** checks, outlier cap (99.9th percentile), stockout flag, weekday-holiday flag.
2. **Merge:** encoded city IDs matched to Open-Meteo cities by temperature/rain similarity (approximate).
3. **EDA, K-means** product groups (k = 4 by silhouette), **OLS regression** on relative sales.
4. **Forecast test:** Random Forest and XGBoost, same baseline features, with and without holidays and weather; time-based train/test split; RMSE/MAE; bootstrap intervals over series.

## Reproduce

```bash
git clone <your-repo-url> && cd fresh-retail-weather-holiday-forecasting
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python scripts/download_retail_data.py
python scripts/download_weather.py
python scripts/analysis.py                # ~15 min; writes results/ and results/figs/
python scripts/make_final_figures.py      # polished figures 3, 7 and 9 -> figures/
```

Or open [`notebooks/Capstone_Analysis.ipynb`](notebooks/Capstone_Analysis.ipynb) (same code, run from the `notebooks/` folder). The script loads 4.5M rows and skips the memory-heavy hourly columns; a machine with 16 GB of RAM or more is a safe choice (I did not measure the minimum). Random seeds are fixed, so results are reproducible.

## Repository layout

```
├── report/        Executive report (PDF + editable Word)
├── scripts/       download_retail_data.py, download_weather.py, analysis.py, make_final_figures.py
├── notebooks/     Capstone_Analysis.ipynb
├── results/       Metrics, regression, clusters (CSV) and results.json (every number in the report)
├── figures/       Figures used in the report
├── data/          Download instructions (raw data not committed)
└── requirements.txt
```

`results/` holds the outputs of the final run; the Tableau-ready CSVs are the same files (`product_clusters.csv`, `forecast_metrics.csv`, `forecast_by_group.csv`, `forecast_vs_actual_daily.csv`).

## Limitations

- Only 90 days from one online retailer in China: no yearly seasonality, and results may not transfer to other markets.
- One 21-day test window; 8,000-series sample; models only lightly tuned.
- The dataset does not name its cities; the Open-Meteo city match is approximate, so the retail data's own weather columns are the main weather measure.
- Days with only a few out-of-stock hours are still partly understated.

## Credits

- Wang, Y., Gu, J., Long, L., Li, X., Shen, L., Fu, Z., Zhou, X. and Jiang, X. (2025). *FreshRetailNet-50K: A Stockout-Annotated Censored Demand Dataset for Latent Demand Recovery and Forecasting in Fresh Retail.* [arXiv:2505.16319](https://arxiv.org/abs/2505.16319)
- Weather data: [Open-Meteo](https://open-meteo.com/)

Code released under the MIT licence (see `LICENSE`).
