"""Download FreshRetailNet-50K (train split) from Hugging Face into data/train.parquet.
Run from the repo root:  python scripts/download_retail_data.py
(Or download train.parquet by hand from the dataset page and put it in data/.)
"""
import os, shutil
from huggingface_hub import hf_hub_download

os.makedirs("data", exist_ok=True)
for name in ("train.parquet", "eval.parquet"):
    p = hf_hub_download("Dingdong-Inc/FreshRetailNet-50K", f"data/{name}", repo_type="dataset")
    shutil.copy(p, f"data/{name}")
    print("saved", f"data/{name}")
