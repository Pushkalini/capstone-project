"""Capstone analysis: do weather and holiday data improve sales forecasts?
Data: FreshRetailNet-50K (train.parquet, 4.5M rows) + Open-Meteo weather (weather.csv).
Run:  python analysis.py   (needs pandas, pyarrow, scikit-learn, xgboost, matplotlib, scipy, statsmodels)
"""
import json, os, warnings
import numpy as np, pandas as pd, pyarrow.parquet as pq
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb
import statsmodels.api as sm

warnings.filterwarnings("ignore")
TRAIN = os.environ.get("TRAIN", "data/train.parquet")
WEATHER = os.environ.get("WEATHER", "data/weather.csv")
OUT = os.environ.get("OUT", "results")
os.makedirs(OUT + "/figs", exist_ok=True)
R = {}                    # all reported numbers
SEED = 42
STOCKOUT_HOURS = 8        # stockout day = out of stock for >= 8 of the 16 selling hours (6:00-22:00)

# ---------- palette (validated default, light mode) ----------
BLUE, ORANGE, AQUA, YELLOW, INK, MUTED, GRID = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#0b0b0b", "#52514e", "#e6e5e1"
plt.rcParams.update({"font.size": 10, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "text.color": INK,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
                     "figure.facecolor": "#fcfcfb", "axes.facecolor": "#fcfcfb", "savefig.dpi": 160})

def save(name):
    plt.tight_layout(); plt.savefig(f"{OUT}/figs/{name}.png"); plt.close()

# ---------- 1. load (daily columns only; hourly list columns are not needed) ----------
cols = ["city_id", "store_id", "first_category_id", "second_category_id", "product_id", "dt", "sale_amount",
        "stock_hour6_22_cnt", "discount", "holiday_flag", "activity_flag", "precpt", "avg_temperature",
        "avg_humidity", "avg_wind_level"]
df = pq.read_table(TRAIN, columns=cols).to_pandas()
df["dt"] = pd.to_datetime(df["dt"])
R["rows"] = len(df); R["columns_used"] = len(cols)
R["stores"] = int(df.store_id.nunique()); R["products"] = int(df.product_id.nunique()); R["cities"] = int(df.city_id.nunique())
R["series"] = int(df.groupby(["store_id", "product_id"]).ngroups)
R["date_min"], R["date_max"] = str(df.dt.min().date()), str(df.dt.max().date())
R["days"] = int(df.dt.nunique())
R["missing_values"] = int(df.isna().sum().sum())
R["duplicate_rows"] = int(df.duplicated(["store_id", "product_id", "dt"]).sum())
R["negative_sales"] = int((df.sale_amount < 0).sum())
R["zero_sales_share"] = float((df.sale_amount == 0).mean())

# ---------- 2. cleaning: sort, stockout flag, calendar ----------
df["sid"] = df.store_id * 1000 + df.product_id
df = df.sort_values(["sid", "dt"]).reset_index(drop=True)
df["stockout"] = (df.stock_hour6_22_cnt >= STOCKOUT_HOURS).astype(np.int8)
df["dow"] = df.dt.dt.dayofweek.astype(np.int8)
df["day_idx"] = (df.dt - df.dt.min()).dt.days.astype(np.int16)
df["weekday_holiday"] = ((df.holiday_flag == 1) & (df.dow < 5)).astype(np.int8)   # public holiday on Mon-Fri
R["stockout_day_share"] = float(df.stockout.mean())
R["any_stockout_hour_share"] = float((df.stock_hour6_22_cnt > 0).mean())
R["all_day_stockout_share"] = float((df.stock_hour6_22_cnt == 16).mean())
R["non_working_day_share"] = float(df.holiday_flag.mean())
R["weekday_holiday_dates"] = sorted(df.loc[df.weekday_holiday == 1, "dt"].dt.strftime("%Y-%m-%d").unique().tolist())
R["sales_outlier_p99"] = float(df.sale_amount.quantile(.99)); R["sales_max"] = float(df.sale_amount.max())
# cap extreme sales at 99.9th percentile (outliers such as promotion spikes)
cap = df.sale_amount.quantile(.999); R["outlier_cap"] = float(cap); R["capped_rows"] = int((df.sale_amount > cap).sum())
df["sales"] = df.sale_amount.clip(upper=cap).astype(np.float32)
R["desc"] = df[["sales", "discount", "precpt", "avg_temperature", "avg_humidity", "avg_wind_level", "stock_hour6_22_cnt"]].describe().T.round(3).to_dict("index")

# ---------- 3. second source: Open-Meteo, city matching ----------
w = pd.read_csv(WEATHER).rename(columns={"time": "dt"}); w["dt"] = pd.to_datetime(w["dt"])
R["weather_rows"] = len(w); R["weather_columns"] = w.shape[1]
c = df.groupby(["city_id", "dt"]).agg(t=("avg_temperature", "mean"), p=("precpt", "mean")).reset_index()
T = c.pivot(index="dt", columns="city_id", values="t"); P = c.pivot(index="dt", columns="city_id", values="p")
wt = w.pivot(index="dt", columns="city", values="temperature_2m_mean").loc[T.index]
wp = w.pivot(index="dt", columns="city", values="precipitation_sum").loc[T.index]
S = np.zeros((T.shape[1], wt.shape[1])); CT = S.copy(); CP = S.copy(); RM = S.copy()
for i, a in enumerate(T.columns):
    for j, b in enumerate(wt.columns):
        CT[i, j] = np.corrcoef(T[a], wt[b])[0, 1]; CP[i, j] = np.corrcoef(P[a], wp[b])[0, 1]
        RM[i, j] = np.sqrt(((T[a] - wt[b]) ** 2).mean())
S = CT + CP - RM / 5
ri, ci = linear_sum_assignment(-S)
match = {int(T.columns[i]): wt.columns[j] for i, j in zip(ri, ci)}
R["city_match_mean_temp_corr"] = float(np.mean([CT[i, j] for i, j in zip(ri, ci)]))
R["city_match_mean_rain_corr"] = float(np.mean([CP[i, j] for i, j in zip(ri, ci)]))
R["city_match_min_temp_corr"] = float(np.min([CT[i, j] for i, j in zip(ri, ci)]))
marg = [np.sort(S[i])[::-1][0] - np.sort(S[i])[::-1][1] for i in ri]
R["city_match_low_margin_cities"] = int(sum(m < 0.1 for m in marg))
df["city_name"] = df.city_id.map(match)
wk = w.rename(columns={"city": "city_name", "temperature_2m_max": "om_tmax", "temperature_2m_min": "om_tmin",
                       "sunshine_duration": "om_sun", "wind_speed_10m_max": "om_wind"})[
    ["city_name", "dt", "om_tmax", "om_tmin", "om_sun", "om_wind"]]
df = df.merge(wk, on=["city_name", "dt"], how="left")
R["open_meteo_merge_missing"] = int(df[["om_tmax", "om_sun"]].isna().any(axis=1).sum())
df = df.sort_values(["sid", "dt"]).reset_index(drop=True)
df["om_sun"] = df["om_sun"] / 3600.0       # seconds -> hours

# ---------- 4. EDA figures ----------
daily = df.groupby("dt").agg(sales=("sales", "sum"), hol=("weekday_holiday", "max"), nonwork=("holiday_flag", "max"))
fig, ax = plt.subplots(figsize=(8, 3.6))
ax.plot(daily.index, daily.sales / 1e3, color=BLUE, lw=2)
for d0 in daily.index[daily.hol == 1]:
    ax.axvspan(d0 - pd.Timedelta(hours=12), d0 + pd.Timedelta(hours=12), color=YELLOW, alpha=.25, lw=0)
ax.set_xlabel("Date (2024)"); ax.set_ylabel("Total daily sales (thousand units, scaled)")
ax.set_title("Total daily sales, with weekday public holidays shaded", loc="left", fontsize=10)
save("fig1_sales_over_time")
dow = df.assign(rel=df.sales / df.groupby("sid").sales.transform("mean")).groupby("dow").rel.mean()
R["dow_relative_sales"] = dow.round(3).to_dict()
fig, ax = plt.subplots(figsize=(6, 3.4))
ax.bar(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], dow.values, color=BLUE, width=.55)
ax.axhline(1, color=MUTED, lw=1); ax.set_ylabel("Sales relative to the series average"); ax.set_xlabel("Day of week")
ax.set_title("Weekly pattern", loc="left", fontsize=10); ax.set_ylim(0.8, dow.max() * 1.05)
save("fig2_day_of_week")
cm = df[["sales", "discount", "activity_flag", "holiday_flag", "weekday_holiday", "precpt", "avg_temperature",
         "avg_humidity", "avg_wind_level", "stock_hour6_22_cnt"]].copy()
cm["rel_sales"] = df.sales / df.groupby("sid").sales.transform("mean")
corr = cm.drop(columns="sales").corr()
R["corr_with_rel_sales"] = corr["rel_sales"].drop("rel_sales").round(3).to_dict()
fig, ax = plt.subplots(figsize=(7, 5.6)); ax.grid(False)
im = ax.imshow(corr.values, cmap="RdBu_r", vmin=-1, vmax=1)
names = ["Discount", "Promo activity", "Non-working day", "Weekday holiday", "Rainfall", "Temperature", "Humidity", "Wind",
         "Out-of-stock hours", "Relative sales"]
ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=45, ha="right"); ax.set_yticks(range(len(names))); ax.set_yticklabels(names)
for i in range(len(names)):
    for j in range(len(names)):
        ax.text(j, i, f"{corr.values[i, j]:.2f}", ha="center", va="center", fontsize=7, color=INK)
plt.colorbar(im, fraction=.046).set_label("Correlation")
ax.set_title("Correlation heatmap", loc="left", fontsize=10); save("fig3_correlation")

# ---------- 5. K-means product clustering ----------
pd_day = df.groupby(["product_id", "dt"]).agg(s=("sales", "sum"), so=("stock_hour6_22_cnt", "mean"), dow=("dow", "first")).reset_index()
g = pd_day.groupby("product_id")
feat = pd.DataFrame({"mean_sales": g.s.mean(), "cv": g.s.std() / g.s.mean(), "stockout_hours": g.so.mean()})
wk_pat = pd_day.groupby(["product_id", "dow"]).s.mean().unstack()
feat["weekly_pattern"] = wk_pat.std(axis=1) / wk_pat.mean(axis=1)
feat["log_mean_sales"] = np.log(feat.mean_sales)
X = StandardScaler().fit_transform(feat[["log_mean_sales", "cv", "weekly_pattern", "stockout_hours"]])
sil = {}
for k in range(2, 9):
    sil[k] = float(silhouette_score(X, KMeans(k, n_init=10, random_state=SEED).fit_predict(X)))
R["silhouette_by_k"] = sil
inert = {k: float(KMeans(k, n_init=10, random_state=SEED).fit(X).inertia_) for k in range(2, 9)}
K = int(os.environ.get("K", 0)) or max(sil, key=sil.get)
R["k_chosen"] = K
feat["cluster"] = KMeans(K, n_init=10, random_state=SEED).fit_predict(X)
prof = feat.groupby("cluster").agg(products=("mean_sales", "size"), mean_sales=("mean_sales", "mean"), cv=("cv", "mean"),
                                   weekly_pattern=("weekly_pattern", "mean"), stockout_hours=("stockout_hours", "mean")).round(3)
R["cluster_profile"] = prof.to_dict("index")
fig, axs = plt.subplots(1, 2, figsize=(8.5, 3.4))
axs[0].plot(list(inert), list(inert.values()), color=BLUE, lw=2, marker="o", ms=5); axs[0].set_xlabel("Number of groups (k)")
axs[0].set_ylabel("Within-group spread (inertia)"); axs[0].set_title("Elbow method", loc="left", fontsize=10)
axs[1].plot(list(sil), list(sil.values()), color=ORANGE, lw=2, marker="o", ms=5); axs[1].set_xlabel("Number of groups (k)")
axs[1].set_ylabel("Silhouette score"); axs[1].set_title("Silhouette score", loc="left", fontsize=10); save("fig4_choose_k")
feat.to_csv(OUT + "/product_clusters.csv")
cols_c = [BLUE, ORANGE, AQUA, YELLOW, "#e87ba4", "#008300"]
fig, ax = plt.subplots(figsize=(6.5, 4))
for k in range(K):
    m = feat.cluster == k; ax.scatter(feat.mean_sales[m], feat.cv[m], s=14, color=cols_c[k], label=f"Group {k + 1} ({m.sum()} products)", alpha=.8, edgecolor="#fcfcfb", lw=.5)
ax.set_xscale("log"); ax.set_xlabel("Average daily sales per product (log scale)"); ax.set_ylabel("Variability (std / mean)")
ax.legend(frameon=False, fontsize=8); ax.set_title("Product groups", loc="left", fontsize=10); save("fig5_clusters")
df = df.merge(feat[["cluster"]].reset_index(), on="product_id", how="left")
df = df.sort_values(["sid", "dt"]).reset_index(drop=True)

# ---------- 6. regression on relative sales (non-stockout days) ----------
ok = df[df.stockout == 0].copy()
ok["rel"] = ok.sales / ok.groupby("sid").sales.transform("mean")
dm = pd.get_dummies(ok.dow, prefix="dow", drop_first=True).astype(float)
Xr = pd.concat([ok[["discount", "activity_flag", "weekday_holiday", "precpt", "avg_temperature", "avg_humidity", "avg_wind_level"]], dm], axis=1)
Xr = (Xr - Xr.mean()) / Xr.std()
mod = sm.OLS(ok.rel.values, sm.add_constant(Xr.values)).fit(cov_type="HC1")
tab = pd.DataFrame({"coef_per_1sd": mod.params[1:], "ci_low": mod.conf_int()[1:, 0], "ci_high": mod.conf_int()[1:, 1], "p": mod.pvalues[1:]}, index=Xr.columns)
R["regression_r2"] = float(mod.rsquared); R["regression_n"] = int(mod.nobs)
R["regression"] = tab.round(4).to_dict("index"); tab.to_csv(OUT + "/regression.csv")
show = tab.drop(index=[c for c in tab.index if c.startswith("dow_")])
lab = {"discount": "Discount (lower price)", "activity_flag": "Promo activity", "weekday_holiday": "Weekday public holiday",
       "precpt": "Rainfall", "avg_temperature": "Temperature", "avg_humidity": "Humidity", "avg_wind_level": "Wind"}
fig, ax = plt.subplots(figsize=(6.5, 3.4)); y = np.arange(len(show))[::-1]
ax.hlines(y, show.ci_low, show.ci_high, color=BLUE, lw=2); ax.scatter(show.coef_per_1sd, y, color=BLUE, s=36, zorder=3)
ax.axvline(0, color=MUTED, lw=1); ax.set_yticks(y); ax.set_yticklabels([lab[i] for i in show.index])
ax.set_xlabel("Change in relative sales per 1 standard deviation (95% interval)"); ax.set_title("Regression effects", loc="left", fontsize=10)
save("fig6_regression")

# ---------- 7. forecast comparison ----------
rng = np.random.default_rng(SEED)
nS, nD = df.sid.nunique(), 90
assert len(df) == nS * nD
def arr(col): return df[col].values.reshape(nS, nD)
sales = arr("sales").astype(np.float32)
def lag(a, k):
    o = np.full_like(a, np.nan, dtype=np.float32); o[:, k:] = a[:, :-k]; return o
L = {k: lag(sales, k) for k in (1, 7, 14, 28)}
roll7 = np.nanmean(np.stack([lag(sales, k) for k in range(1, 8)]), axis=0)
hol = arr("weekday_holiday").astype(np.float32); nonw = arr("holiday_flag").astype(np.float32)
def lead(a, k):
    o = np.zeros_like(a); o[:, :-k] = a[:, k:]; return o
hol_next = lead(hol, 1); hol_next3 = sum(lead(hol, k) for k in (1, 2, 3))
nonw_next = lead(nonw, 1)
feats = {"dow": arr("dow"), "day_idx": arr("day_idx"), "discount": arr("discount"), "activity_flag": arr("activity_flag"),
         "lag1": L[1], "lag7": L[7], "lag14": L[14], "lag28": L[28], "roll7": roll7}
BASE = list(feats)
HOLW = {"weekday_holiday": hol, "nonworking_day": nonw, "holiday_tomorrow": hol_next, "holidays_next3": hol_next3}
WEATHER_F = {"precpt": arr("precpt"), "avg_temperature": arr("avg_temperature"), "avg_humidity": arr("avg_humidity"), "avg_wind_level": arr("avg_wind_level")}
OM = {"om_tmax": arr("om_tmax"), "om_tmin": arr("om_tmin"), "om_sun": arr("om_sun"), "om_wind": arr("om_wind")}
allf = {**feats, **HOLW, **WEATHER_F, **OM}
sets = {"Baseline": BASE,
        "Baseline + holidays": BASE + list(HOLW),
        "Baseline + weather": BASE + list(WEATHER_F),
        "Baseline + weather + holidays": BASE + list(HOLW) + list(WEATHER_F),
        "Baseline + weather + holidays + Open-Meteo": BASE + list(HOLW) + list(WEATHER_F) + list(OM)}
N_SER = int(os.environ.get("N_SER", 8000))
sel = rng.choice(nS, N_SER, replace=False)
dates = np.sort(df.dt.unique())
SPLIT = np.datetime64("2024-06-04")           # train: up to 4 Jun; test: 5-25 Jun (21 days, includes Dragon Boat holiday 10 Jun)
d_idx = np.arange(nD)
tr_days = (dates <= SPLIT) & (d_idx >= 28); te_days = dates > SPLIT
so = arr("stockout")
cl = df.groupby("sid").cluster.first().values        # sorted by sid like arr()
def build(names, days, series, drop_stockout):
    m = np.zeros((nS, nD), bool); m[np.ix_(series, np.where(days)[0])] = True
    if drop_stockout: m &= (so == 0)
    X = np.column_stack([allf[n][m] for n in names]); return X, sales[m], m
R["n_series_modelled"] = int(N_SER); R["train_days"] = int(tr_days.sum()); R["test_days"] = int(te_days.sum())
res, preds, imps = {}, {}, {}
Xte_cache = {}
for mname, make in {"Random Forest": lambda: RandomForestRegressor(150, min_samples_leaf=5, max_features=.5, n_jobs=-1, random_state=SEED),
                    "XGBoost": lambda: xgb.XGBRegressor(n_estimators=400, learning_rate=.05, max_depth=7, subsample=.8, colsample_bytree=.8, n_jobs=-1, random_state=SEED, tree_method="hist")}.items():
    for sname, names in sets.items():
        Xtr, ytr, _ = build(names, tr_days, sel, True)
        Xtr = np.nan_to_num(Xtr, nan=-1)
        Xte, yte, mte = build(names, te_days, sel, False)
        Xte = np.nan_to_num(Xte, nan=-1)
        mdl = make().fit(Xtr, ytr); p = mdl.predict(Xte)
        res[(mname, sname)] = p; Xte_cache[sname] = (yte, mte)
        if sname == "Baseline + weather + holidays":
            imps[mname] = dict(zip(names, (mdl.feature_importances_).round(4)))
yte, mte = Xte_cache["Baseline"]
so_te = so[mte].astype(bool); cl_te = np.broadcast_to(cl[:, None], (nS, nD))[mte]; sid_te = np.broadcast_to(np.arange(nS)[:, None], (nS, nD))[mte]
base_lag7 = np.nan_to_num(L[7][mte], nan=0)
def metrics(y, p): return float(np.sqrt(np.mean((y - p) ** 2))), float(np.mean(np.abs(y - p)))
rows = []
for (mname, sname), p in res.items():
    for scope, msk in {"non-stockout days": ~so_te, "all days": np.ones_like(so_te)}.items():
        rm, ma = metrics(yte[msk], p[msk]); rows.append(dict(model=mname, features=sname, test_days=scope, RMSE=rm, MAE=ma))
for scope, msk in {"non-stockout days": ~so_te, "all days": np.ones_like(so_te)}.items():
    rm, ma = metrics(yte[msk], base_lag7[msk]); rows.append(dict(model="Naive (same weekday last week)", features="-", test_days=scope, RMSE=rm, MAE=ma))
M = pd.DataFrame(rows); M.to_csv(OUT + "/forecast_metrics.csv", index=False); R["forecast_metrics"] = M.round(4).to_dict("records")
R["test_rows"] = int(len(yte)); R["test_rows_nonstockout"] = int((~so_te).sum()); R["train_rows"] = int(len(build(BASE, tr_days, sel, True)[1]))
R["importance_weather_holidays_model"] = imps
# bootstrap by series: RMSE difference (baseline - weather+holidays) on non-stockout days
def boot(mname, other, B=300):
    pa, pb = res[(mname, "Baseline")], res[(mname, other)]; keep = ~so_te
    s = sid_te[keep]; ea = (yte[keep] - pa[keep]) ** 2; eb = (yte[keep] - pb[keep]) ** 2
    ids, inv = np.unique(s, return_inverse=True); sa = np.bincount(inv, ea); sb = np.bincount(inv, eb); cnt = np.bincount(inv)
    out = []
    for _ in range(B):
        b = rng.integers(0, len(ids), len(ids)); out.append(np.sqrt(sa[b].sum() / cnt[b].sum()) - np.sqrt(sb[b].sum() / cnt[b].sum()))
    return [float(np.percentile(out, 2.5)), float(np.mean(out)), float(np.percentile(out, 97.5))]
R["rmse_gain_ci"] = {f"{m} | {o}": boot(m, o) for m in ("Random Forest", "XGBoost")
                     for o in ("Baseline + holidays", "Baseline + weather", "Baseline + weather + holidays", "Baseline + weather + holidays + Open-Meteo")}
# per-cluster results (XGBoost and RF), non-stockout days
pc = []
for mname in ("Random Forest", "XGBoost"):
    for k in range(K):
        msk = (cl_te == k) & ~so_te
        b = metrics(yte[msk], res[(mname, "Baseline")][msk]); f = metrics(yte[msk], res[(mname, "Baseline + weather + holidays")][msk])
        pc.append(dict(model=mname, cluster=k + 1, n=int(msk.sum()), rmse_base=b[0], rmse_full=f[0], mae_base=b[1], mae_full=f[1],
                       rmse_gain_pct=100 * (b[0] - f[0]) / b[0], mae_gain_pct=100 * (b[1] - f[1]) / b[1]))
PC = pd.DataFrame(pc); PC.to_csv(OUT + "/forecast_by_group.csv", index=False); R["by_group"] = PC.round(4).to_dict("records")
# holiday-window check: errors on weekday-holiday test days only
hmsk = (hol[mte] == 1) & ~so_te
R["holiday_test_rows"] = int(hmsk.sum())
if hmsk.sum() > 100:
    R["holiday_days_metrics"] = {f"{m} | {s}": metrics(yte[hmsk], res[(m, s)][hmsk]) for m in ("Random Forest", "XGBoost") for s in ("Baseline", "Baseline + holidays", "Baseline + weather + holidays")}

# extra: per-group ablation (holidays only / weather only / both) and error on total daily sales
pa_rows = []
for mname in ("Random Forest", "XGBoost"):
    for k in range(K):
        msk = (cl_te == k) & ~so_te
        b = metrics(yte[msk], res[(mname, "Baseline")][msk])[0]
        for sname in ("Baseline + holidays", "Baseline + weather", "Baseline + weather + holidays"):
            f = metrics(yte[msk], res[(mname, sname)][msk])[0]
            pa_rows.append(dict(model=mname, cluster=k + 1, features=sname, rmse_base=b, rmse=f, gain_pct=100 * (b - f) / b))
pd.DataFrame(pa_rows).to_csv(OUT + "/forecast_by_group_ablation.csv", index=False)
day_te_all = np.broadcast_to(d_idx[None, :], (nS, nD))[mte]
agg = {}
for (mname, sname), p in res.items():
    t = pd.DataFrame({"d": day_te_all, "y": yte, "p": p}).groupby("d").sum()
    agg[f"{mname} | {sname}"] = float(np.mean(np.abs(t.y - t.p) / t.y))
R["total_daily_mape"] = agg
# sensitivity: stockout threshold 4 hours -> share flagged only (full re-fit not repeated)
R["stockout_share_ge4"] = float((df.stock_hour6_22_cnt >= 4).mean()); R["stockout_share_ge12"] = float((df.stock_hour6_22_cnt >= 12).mean())

# figures: model comparison and importance
mm = M[(M.test_days == "non-stockout days") & M.features.isin(["Baseline", "Baseline + weather + holidays"])]
fig, ax = plt.subplots(figsize=(6.5, 3.6)); xs = np.arange(2); wd = .32
for i, (f, colr, lbl) in enumerate([("Baseline", BLUE, "Baseline (sales history, calendar, price)"), ("Baseline + weather + holidays", ORANGE, "Baseline + weather + holidays")]):
    v = [mm[(mm.model == m) & (mm.features == f)].RMSE.iloc[0] for m in ("Random Forest", "XGBoost")]
    ax.bar(xs + (i - .5) * wd, v, wd - .03, color=colr, label=lbl)
    for x_, v_ in zip(xs + (i - .5) * wd, v): ax.text(x_, v_, f"{v_:.4f}", ha="center", va="bottom", fontsize=8, color=INK)
ax.set_xticks(xs); ax.set_xticklabels(["Random Forest", "XGBoost"]); ax.set_ylabel("RMSE on unseen days (lower is better)")
ax.set_ylim(0, mm.RMSE.max() * 1.18); ax.legend(frameon=False, fontsize=8, loc="upper right"); ax.set_title("Forecast error: with and without weather and holidays", loc="left", fontsize=10)
save("fig7_model_comparison")
imp = pd.Series(imps["XGBoost"]).sort_values()
nice = {"dow": "Day of week", "day_idx": "Trend (day number)", "discount": "Discount", "activity_flag": "Promo activity", "lag1": "Sales 1 day ago", "lag7": "Sales 7 days ago",
        "lag14": "Sales 14 days ago", "lag28": "Sales 28 days ago", "roll7": "Rolling 7-day average", "weekday_holiday": "Weekday holiday", "nonworking_day": "Non-working day",
        "holiday_tomorrow": "Holiday tomorrow", "holidays_next3": "Holidays in next 3 days", "precpt": "Rainfall", "avg_temperature": "Temperature", "avg_humidity": "Humidity", "avg_wind_level": "Wind"}
fig, ax = plt.subplots(figsize=(6.5, 4.6)); wx = {"precpt", "avg_temperature", "avg_humidity", "avg_wind_level"}; hx = set(HOLW)
colors = [ORANGE if i in wx else (YELLOW if i in hx else BLUE) for i in imp.index]
ax.barh([nice[i] for i in imp.index], imp.values, color=colors, height=.65); ax.set_xlabel("Feature importance (XGBoost, share of total)")
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=BLUE, label="Sales history and calendar"), Patch(color=ORANGE, label="Weather"), Patch(color=YELLOW, label="Holidays")], frameon=False, fontsize=8, loc="lower right")
ax.set_title("What the model relies on", loc="left", fontsize=10); save("fig8_importance")
g_ = PC[PC.model == "XGBoost"]
fig, ax = plt.subplots(figsize=(6.5, 3.4))
ax.bar([f"Group {c}" for c in g_.cluster], g_.rmse_gain_pct, color=BLUE, width=.5); ax.axhline(0, color=MUTED, lw=1)
for i, v in enumerate(g_.rmse_gain_pct): ax.text(i, v, f"{v:.1f}%", ha="center", va="bottom" if v >= 0 else "top", fontsize=8)
ax.set_ylabel("RMSE improvement from weather + holidays (%)"); ax.set_title("Where weather and holidays help (XGBoost)", loc="left", fontsize=10); save("fig9_by_group")
# forecast vs actual (XGBoost, total test-sample sales by day)
px = res[("XGBoost", "Baseline + weather + holidays")]; pb_ = res[("XGBoost", "Baseline")]
day_te = np.broadcast_to(d_idx[None, :], (nS, nD))[mte]
ds = pd.DataFrame({"d": day_te, "y": yte, "px": px, "pb": pb_}).groupby("d").sum()
fig, ax = plt.subplots(figsize=(8, 3.6)); xd = pd.to_datetime(dates[ds.index])
ax.plot(xd, ds.y / 1e3, color=INK, lw=2, label="Actual"); ax.plot(xd, ds.pb / 1e3, color=BLUE, lw=1.6, label="Baseline forecast"); ax.plot(xd, ds.px / 1e3, color=ORANGE, lw=1.6, label="With weather + holidays")
ax.set_ylabel("Daily sales, modelled sample (thousand units)"); ax.set_xlabel("Date (2024)"); ax.legend(frameon=False, fontsize=8); ax.set_title("Forecast vs. actual (XGBoost, test period)", loc="left", fontsize=10)
save("fig10_forecast_vs_actual")
R["fva_mape_total_base"] = float(np.mean(np.abs(ds.y - ds.pb) / ds.y)); R["fva_mape_total_full"] = float(np.mean(np.abs(ds.y - ds.px) / ds.y))
ds.assign(date=xd).to_csv(OUT + "/forecast_vs_actual_daily.csv")
json.dump(R, open(OUT + "/results.json", "w"), indent=1, default=float)
print("done")
