"""Download daily weather for 18 large Chinese cities from the free Open-Meteo archive API.
Saves data/weather.csv (second data source). Run from the repo root:  python scripts/download_weather.py

NOTE: FreshRetailNet-50K does not name its cities (IDs are encoded), so this list of 18 cities is an
assumption. scripts/analysis.py matches each encoded city to the closest Open-Meteo city using
temperature and rainfall; the match is approximate (see README, Limitations).
"""
import os, requests, pandas as pd

CITIES = {"Beijing": (39.9, 116.4), "Shanghai": (31.2, 121.5), "Guangzhou": (23.1, 113.3),
          "Shenzhen": (22.5, 114.1), "Hangzhou": (30.3, 120.2), "Nanjing": (32.1, 118.8),
          "Suzhou": (31.3, 120.6), "Wuhan": (30.6, 114.3), "Chengdu": (30.7, 104.1),
          "Chongqing": (29.6, 106.5), "Tianjin": (39.1, 117.2), "Xi'an": (34.3, 108.9),
          "Changsha": (28.2, 112.9), "Zhengzhou": (34.8, 113.7), "Ningbo": (29.9, 121.5),
          "Hefei": (31.8, 117.3), "Wuxi": (31.5, 120.3), "Fuzhou": (26.1, 119.3)}
DAILY = "temperature_2m_mean,temperature_2m_max,temperature_2m_min,precipitation_sum,sunshine_duration,wind_speed_10m_max"

frames = []
for city, (lat, lon) in CITIES.items():
    r = requests.get("https://archive-api.open-meteo.com/v1/archive", timeout=60, params={
        "latitude": lat, "longitude": lon, "start_date": "2024-03-01", "end_date": "2024-06-30",
        "daily": DAILY, "timezone": "Asia/Shanghai"})
    r.raise_for_status()
    d = pd.DataFrame(r.json()["daily"]); d["city"] = city; frames.append(d)
os.makedirs("data", exist_ok=True)
out = pd.concat(frames); out.to_csv("data/weather.csv", index=False)
print(f"Saved data/weather.csv: {out.shape[0]} rows x {out.shape[1]} columns")
