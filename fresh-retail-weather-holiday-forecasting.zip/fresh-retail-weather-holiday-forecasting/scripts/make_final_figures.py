"""Regenerates the three polished figures used in the report (fig3, fig7, fig9).
Run from the repo root AFTER scripts/analysis.py:  python scripts/make_final_figures.py"""
import pandas as pd, numpy as np, pyarrow.parquet as pq, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
BLUE, ORANGE, YELLOW, INK, MUTED, GRID = "#2a78d6", "#eb6834", "#eda100", "#0b0b0b", "#52514e", "#e6e5e1"
plt.rcParams.update({"font.size": 10, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "text.color": INK, "xtick.color": MUTED, "ytick.color": MUTED,
 "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "grid.linewidth": .6, "axes.axisbelow": True,
 "figure.facecolor": "#fcfcfb", "axes.facecolor": "#fcfcfb", "savefig.dpi": 160})
import os; os.makedirs("figures",exist_ok=True); O="figures/"
c=["sale_amount","discount","activity_flag","holiday_flag","dt","store_id","product_id","precpt","avg_temperature","avg_humidity","avg_wind_level","stock_hour6_22_cnt"]
d=pq.read_table("data/train.parquet",columns=c).to_pandas(); d["dt"]=pd.to_datetime(d.dt)
d["sid"]=d.store_id*1000+d.product_id; d["sales"]=d.sale_amount.clip(upper=d.sale_amount.quantile(.999))
d["weekday_holiday"]=((d.holiday_flag==1)&(d.dt.dt.dayofweek<5)).astype(int)
d["rel_sales"]=d.sales/d.groupby("sid").sales.transform("mean")
cm=d[["discount","activity_flag","holiday_flag","weekday_holiday","precpt","avg_temperature","avg_humidity","avg_wind_level","stock_hour6_22_cnt","rel_sales"]]
corr=cm.corr(); names=["Discount","Promo activity","Non-working day","Weekday holiday","Rainfall","Temperature","Humidity","Wind","Out-of-stock hours","Relative sales"]
fig,ax=plt.subplots(figsize=(7,5.6)); ax.grid(False); im=ax.imshow(corr.values,cmap="RdBu_r",vmin=-1,vmax=1)
ax.set_xticks(range(10)); ax.set_xticklabels(names,rotation=45,ha="right"); ax.set_yticks(range(10)); ax.set_yticklabels(names)
for i in range(10):
    for j in range(10): ax.text(j,i,f"{corr.values[i,j]:.2f}",ha="center",va="center",fontsize=7,color="white" if abs(corr.values[i,j])>.6 else INK)
plt.colorbar(im,fraction=.046).set_label("Correlation"); ax.set_title("Correlation heatmap",loc="left",fontsize=10); plt.tight_layout(); plt.savefig(O+"fig3_correlation.png"); plt.close()
a=pd.read_csv("results/forecast_by_group_ablation.csv")
gn={1:"Group 1\nLow volume\n(356)",2:"Group 2\nSteady, high\nvolume (335)",3:"Group 3\nOften out of\nstock (108)",4:"Group 4\nUnpredictable\n(66)"}
fig,axs=plt.subplots(1,2,figsize=(9,3.8),sharey=True)
for ax,m in zip(axs,["Random Forest","XGBoost"]):
    x=np.arange(4); w=.36
    for i,(f,col,l) in enumerate([("Baseline + holidays",YELLOW,"Adding holidays"),("Baseline + weather",ORANGE,"Adding weather")]):
        v=[a[(a.model==m)&(a.cluster==k)&(a.features==f)].gain_pct.iloc[0] for k in range(1,5)]
        ax.bar(x+(i-.5)*w,v,w-.03,color=col,label=l)
        for xx,vv in zip(x+(i-.5)*w,v): ax.text(xx,vv,f"{vv:.0f}%" if abs(vv)>=1 else f"{vv:.1f}%",ha="center",va="bottom" if vv>=0 else "top",fontsize=7)
    ax.axhline(0,color=MUTED,lw=1); ax.set_xticks(x); ax.set_xticklabels([gn[k] for k in range(1,5)],fontsize=7.5); ax.set_title(m,loc="left",fontsize=10)
axs[0].set_ylabel("Change in RMSE vs. baseline (%)\n(above 0 = better)"); axs[0].legend(frameon=False,fontsize=8,loc="lower left"); axs[0].set_ylim(-24,17)
plt.tight_layout(); plt.savefig(O+"fig9_by_group.png"); plt.close()

# ---- figure 7 ----
m=pd.read_csv("results/forecast_metrics.csv"); m=m[m.test_days=="non-stockout days"]
sets=["Baseline","Baseline + holidays","Baseline + weather","Baseline + weather + holidays"]
lab=["Baseline (history, calendar, price)","+ holidays","+ weather","+ weather + holidays"]
fig,ax=plt.subplots(figsize=(7.5,3.6)); y=np.arange(4)[::-1]
for mn,col,off in [("Random Forest",BLUE,.12),("XGBoost",ORANGE,-.12)]:
    v=[m[(m.model==mn)&(m.features==s)].RMSE.iloc[0] for s in sets]
    ax.scatter(v,y+off,color=col,s=46,label=mn,zorder=3)
    for vv,yy in zip(v,y+off): ax.text(vv+.004,yy,f"{vv:.3f}",va="center",fontsize=8)
nv=m[m.model.str.startswith("Naive")].RMSE.iloc[0]; ax.axvline(nv,color=MUTED,lw=1,ls="--"); ax.text(nv-.004,3.45,"Naive: same weekday last week",ha="right",fontsize=8,color=MUTED)
ax.set_yticks(y); ax.set_yticklabels(lab); ax.set_xlabel("RMSE on unseen days (lower is better)"); ax.set_xlim(.52,.78); ax.legend(frameon=False,fontsize=8,loc="lower right")
ax.set_title("Forecast error by feature set",loc="left",fontsize=10); plt.tight_layout(); plt.savefig("figures/fig7_model_comparison.png"); plt.close()
