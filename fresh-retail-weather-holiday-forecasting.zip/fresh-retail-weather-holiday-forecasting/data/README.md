# Data

The raw data files are large and are **not** stored in this repository. Create them with:

```bash
python scripts/download_retail_data.py   # data/train.parquet (and eval.parquet), about 4.5M rows
python scripts/download_weather.py       # data/weather.csv, 2,196 rows x 8 columns
```

| File | Source | Licence |
|---|---|---|
| `train.parquet`, `eval.parquet` | [FreshRetailNet-50K](https://huggingface.co/datasets/Dingdong-Inc/FreshRetailNet-50K) (Dingdong) | CC BY 4.0 |
| `weather.csv` | [Open-Meteo Historical Weather API](https://open-meteo.com/en/docs) | Open-Meteo terms (free for non-commercial use; attribution required) |

`train.parquet` holds hourly list columns that use a lot of memory. `scripts/analysis.py` reads only the daily columns it needs.
